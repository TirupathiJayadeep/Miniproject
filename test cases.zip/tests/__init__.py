"""
Tests Package Initialization
============================

Pytest will auto-discover all test_*.py files.
No explicit imports needed.
"""
